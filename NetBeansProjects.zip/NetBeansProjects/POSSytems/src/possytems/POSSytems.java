/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package possytems;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.DecimalFormat;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;

/**
 *
 * @author ccadwallader
 */
public class POSSytems implements  ActionListener{
	 
	    JPanel     textPanel, panelForTextFields, completionPanel, totalCompletionPanel,subtotalCompletionPanel,salestaxCompletionPanel,text_Panel;                  
 	    JLabel     titleLabel, itemLabel, itemcodeLabel, subtotalLabel, salestaxLabel, totalLabel;
	
	    JTextField    itemcodeField, loginField;
	    JButton   enterButton, totalButton;
	      
	      
	 public static void main(String[] args) {
	  
	        //declare variables for  calculations      
	        double itemCode, itemName, itemPrice, gasolinesalesTax, dieselsalesTax, electriccarsalesTax,  taxAmount, subTotal, runningTotal, Total;
	         
	        //intitiale variables
	        gasolinesalesTax  = 7.75;
                dieselsalesTax = .08;
                electriccarsalesTax = .03;
	        itemPrice = 0;
	        runningTotal = 0;
	         
	        //perform calculatiuons
	        taxAmount = itemPrice * gasolinesalesTax;
                taxAmount = itemPrice * dieselsalesTax;
                taxAmount = itemPrice * electriccarsalesTax;
	        subTotal = runningTotal;
	        Total = runningTotal + taxAmount;
	         
  
 //declaration for new decimal format
	       DecimalFormat twoDigits = new DecimalFormat("$#,###.00");         
	           
	           // application GUI.
	 
	                  SwingUtilities.invokeLater(new Runnable() {
	            public void run() {
	                createAndShowGUI();
	            }
	        });
	    }	 
	    public JPanel createContentPane (){
	 
	        //main Jpanel for GUI (everything goes in here)
	        JPanel totalGUI = new JPanel();
	        totalGUI.setLayout(null);
	           
	          //title label
	        titleLabel = new JLabel("POS System");
	        titleLabel.setLocation(0,0);
	        titleLabel.setSize(290, 30);
	        titleLabel.setHorizontalAlignment(0);
	        totalGUI.add(titleLabel);
	 
	        //Panel to contain the JLabel
	        textPanel = new JPanel();
	        textPanel.setLayout(null);
	        textPanel.setLocation(10, 35);
	        textPanel.setSize(70,30);       
	        totalGUI.add(textPanel);
	           
	          //Panel for subtotal, tax, and total JLabel
	          text_Panel = new JPanel ();
	          text_Panel.setLayout(null);
	          text_Panel.setLocation(240,150);
	          text_Panel.setSize(85,140);
	          totalGUI.add(text_Panel);
	 
	       //Item code Label
	       itemcodeLabel = new JLabel("Item Code");
	       itemcodeLabel.setLocation(0, 0);
	       itemcodeLabel.setSize(70, 40);
	       itemcodeLabel.setHorizontalAlignment(4);
	       textPanel.add(itemcodeLabel);
	          
	         //subtotal JLabel
	         subtotalLabel = new JLabel("Subtotal = ");
	         subtotalLabel.setLocation(0,0);
	         subtotalLabel.setSize(70,40);
	         subtotalLabel.setHorizontalAlignment (4);
	         text_Panel.add(subtotalLabel);
	          
	         //sales tax JLabel
	         salestaxLabel = new JLabel("Sales Tax = ");
	         salestaxLabel.setLocation(0,45);
	         salestaxLabel.setSize(70,40);
	         salestaxLabel.setHorizontalAlignment (4);
	         text_Panel.add(salestaxLabel);
	          
	         //Total Label
	         totalLabel  = new JLabel("Total = ");
	         totalLabel.setLocation(0,95);
	         totalLabel.setSize(70,40);
	         totalLabel.setHorizontalAlignment (4);
	         text_Panel.add(totalLabel);
	                 
	        // TextFields Panel Container
	          panelForTextFields = new JPanel();
	        panelForTextFields.setLayout(null);
	        panelForTextFields.setLocation(110, 40);
	        panelForTextFields.setSize(100, 40);
	          totalGUI.add(panelForTextFields);
	 
	        //Item code Textfield
	       itemcodeField = new JTextField(8);
	       itemcodeField.setLocation(0, 0);
	       itemcodeField.setSize(100, 30);
	       panelForTextFields.add(itemcodeField);
	 
	        
	        //Panel to contain the completion JLabels
	        completionPanel = new JPanel();
	        completionPanel.setLayout(null);
	        completionPanel.setLocation(240, 35);
	        completionPanel.setSize(200, 40);
	        completionPanel.setBackground(Color.white);
	        totalGUI.add(completionPanel);
	 
	          //panel for subtotal completion
	          subtotalCompletionPanel = new JPanel();
	          subtotalCompletionPanel.setLayout(null);
	          subtotalCompletionPanel.setLocation(325,150);
	          subtotalCompletionPanel.setSize(200,40);
	          subtotalCompletionPanel.setBackground(Color.white);
	          totalGUI.add(subtotalCompletionPanel);
	           
	          //panel for sales tax amount
	          salestaxCompletionPanel = new JPanel();
	          salestaxCompletionPanel.setLayout(null);
	          salestaxCompletionPanel.setLocation(325,200);
	          salestaxCompletionPanel.setSize(200,40);
	          salestaxCompletionPanel.setBackground(Color.white);
	          totalGUI.add(salestaxCompletionPanel);
	           
	          //Panel for Purchas Total completion Panel
	          totalCompletionPanel = new JPanel();
	          totalCompletionPanel.setLayout(null);
	          totalCompletionPanel.setLocation(325,250);
	          totalCompletionPanel.setSize(200,40);
	          totalCompletionPanel.setBackground(Color.white);
	          totalGUI.add(totalCompletionPanel);        
	          totalGUI.add(completionPanel);
	 
			        //item Label
	        itemLabel = new JLabel("");
	        itemLabel.setForeground(Color.red);
	        itemLabel.setLocation(0, 0);
	        itemLabel.setSize(400, 40);
	        completionPanel.add(itemLabel);    
	 
	        // Button for entering UPC item code
	        enterButton = new JButton("Enter");
	        enterButton.setLocation(130, 120);
	        enterButton.setSize(80, 30);
	        enterButton.addActionListener(this);
	        totalGUI.add(enterButton);
	           
	         // Button getting Total
	       totalButton = new JButton("Total");
	       totalButton.setLocation(230, 120);
	       totalButton.setSize(80, 30);
	       totalButton.addActionListener(this);
	       totalGUI.add(totalButton);
	 
	       totalGUI.setOpaque(true);   
	       return totalGUI;
	    }
	 
	     
	    public void actionPerformed(ActionEvent e) {
	 
	        if(e.getSource() == enterButton)
	        {
	            if(itemcodeField.getText().trim().compareTo("105") == 0)
	            {
	                itemLabel.setForeground(Color.black);
	                itemLabel.setText("$12.00........ for full service");
	                     itemLabel.setSize (400, 40);
	            }
	                else if(itemcodeField.getText().trim().compareTo("110") == 0)
	            {
	                itemLabel.setForeground(Color.black);
	                itemLabel.setText("$10.00........ quick and go service");
	                     itemLabel.setSize (400, 40);
	            }
	                  else if(itemcodeField.getText().trim().compareTo("115") == 0)
	            {
	                itemLabel.setForeground(Color.black);
	                itemLabel.setText("0.00........ Full service");
	                     itemLabel.setSize (400, 40);
	            }
	                else if(itemcodeField.getText().trim().compareTo("120") == 0)
	            {
	                itemLabel.setForeground(Color.black);
	                itemLabel.setText("$3.00........ per gallon for regular");
	                     itemLabel.setSize (400, 40);
	            }
	                else if(itemcodeField.getText().trim().compareTo("125") == 0)
	            {
	                itemLabel.setForeground(Color.black);
	                itemLabel.setText("$4.50........ per gallon for premium");
	                     itemLabel.setSize (400, 40);
	            }
	 else if(itemcodeField.getText().trim().compareTo("130") == 0)
	            {
	                itemLabel.setForeground(Color.black);
	                itemLabel.setText("$5.20........ per gallon for diesel");
	                     itemLabel.setSize (400, 40);
	            }
	            else if(itemcodeField.getText().trim().compareTo("135") == 0)
	            {
	                itemLabel.setForeground(Color.black);
	                itemLabel.setText("$1.00........ per Amp-Hr  to charge an electric car 25 Amp-Hr  to charge completely");
	                     itemLabel.setSize (400, 40);
	            }     
	            else
	            {
	                itemLabel.setForeground(Color.red);
	                itemLabel.setText("  Invalid Item Code!");
	            }
	 
	            
	                   }
	    }
	 
	 
	    private static void createAndShowGUI() {
	 
	        JFrame.setDefaultLookAndFeelDecorated(true);
	        JFrame frame = new JFrame("[=]POS Systems [=]");
	 
	        POSSytems gui = new POSSytems();
	        frame.setContentPane(gui.createContentPane());
	         
	        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	        frame.setSize(610, 400);
	        frame.setVisible(true);
	    }
	 
	}//end program


