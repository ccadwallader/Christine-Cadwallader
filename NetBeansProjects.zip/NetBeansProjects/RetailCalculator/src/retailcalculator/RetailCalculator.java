/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package retailcalculator;

import java.awt.Container;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

/**
 * @author ccadwallader
 */
public class RetailCalculator extends JFrame implements ActionListener {

    //fields and labels

    private JPanel namePanel;
    private JPanel pricePanel;
    private JPanel retailPricePanel;
    private JPanel buttonPanel;
    private JPanel tablePanel;
    private JLabel itemNameLabel;
    private JLabel departmentLabel;
    private JLabel originalPriceLabel;
    private JLabel discountLabel;
    private JLabel retailPriceLabel;
    private JComboBox departmentBox;
    private JTextField itemName;
    private JTextField originalPrice;
    private JTextField discount;
    private JTextField retailPrice;
    private JButton calculateButton;
    private JButton clearButton;
    private JButton exitButton;
    private JTable calculatorTable;
    private DefaultTableModel tableModel;
    //to count the rows in table
    int itemCount = 0;
    //widht aand height of GUI
    private final int WINDOW_WIDTH = 600;
    private final int WINDOW_HEIGHT = 200;
    //defines the array for the charityBox combo box
    private String[] department = {"", "Men's clothing", "Women's clothing", "house wares"};

    //sets JFrame constructor: calls build panel methods and adds panels, defines layout
    public RetailCalculator() {
        super("Retail Calculator"); //calls JFrame constructor
        setSize(WINDOW_WIDTH, WINDOW_HEIGHT); //setting dimentions
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); //close on hitting 'X' button

        setVisible(true);
        //building panels
        buildNamePanel();
        buildPricePanel();
        buildRetailPricePanel();
        buildButtonPanel();
        buildTablePanel();

        Container retailContainer = getContentPane();
        //adding panels to GUI
        retailContainer.setLayout(new BoxLayout(retailContainer, BoxLayout.PAGE_AXIS));
        retailContainer.add(namePanel);
        retailContainer.add(pricePanel);
        retailContainer.add(retailPricePanel);
        retailContainer.add(buttonPanel);
        retailContainer.add(tablePanel);

        pack();
    }

    //builds name panel: creates and adds first and last name labels and textfields    
    private void buildNamePanel() {
        namePanel = new JPanel();

        itemNameLabel = new JLabel("Item Name");
        itemName = new JTextField(19);

        departmentLabel = new JLabel("Select Charity");
        departmentBox = new JComboBox(department);


        namePanel.add(itemNameLabel);
        namePanel.add(itemName);
        namePanel.add(departmentLabel);
        namePanel.add(departmentBox);

    }

    //builds name panel: creates and adds first and last name labels and textfields    
    private void buildPricePanel() {
        pricePanel = new JPanel();

        originalPriceLabel = new JLabel("Original Price");
        originalPrice = new JTextField(19);

        discountLabel = new JLabel("Discount");
        discount = new JTextField(19);


        pricePanel.add(originalPriceLabel);
        pricePanel.add(originalPrice);
        pricePanel.add(discountLabel);
        pricePanel.add(discount);

    }

    //builds name panel: creates and adds first and last name labels and textfields    
    private void buildRetailPricePanel() {
        retailPricePanel = new JPanel();

        retailPriceLabel = new JLabel("Retails Price");
        retailPrice = new JTextField(19);
        retailPrice.setEnabled(false);

        retailPricePanel.add(retailPriceLabel);
        retailPricePanel.add(retailPrice);


    }

    //builds button panel: creates and adds buttons to panel and calls action listeners for buttons
    private void buildButtonPanel() {
        buttonPanel = new JPanel();

        calculateButton = new JButton("Calculate");
        calculateButton.addActionListener(this);

        clearButton = new JButton("Clear");
        clearButton.addActionListener(this);


        exitButton = new JButton("Exit");
        exitButton.addActionListener(this);

        buttonPanel.add(calculateButton);
        buttonPanel.add(clearButton);

        buttonPanel.add(exitButton);
    }

    //builds table panel: creates and displays table
    private void buildTablePanel() {
        tablePanel = new JPanel();
        calculatorTable = new JTable();
        calculatorTable.setPreferredScrollableViewportSize(new Dimension(780, 100));
        tableModel = new DefaultTableModel(0, 5);

        //adds headings to table  
        String[] headings = {"Item Name", "Department", "Original Price", "Discount", "Sales Price"};
        tableModel.setColumnIdentifiers(headings);
        calculatorTable.setModel(tableModel);

        JScrollPane scroll = new JScrollPane(calculatorTable,
                JScrollPane.VERTICAL_SCROLLBAR_ALWAYS,
                JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
        scroll.setViewportView(calculatorTable);

        tablePanel.add(scroll);
        scroll.setViewportView(calculatorTable);
    }

    //Calls button methods    
    public void actionPerformed(ActionEvent event) {
        JButton source = (JButton) event.getSource();
        if (source == calculateButton) {
            addLine();
        } else if (source == clearButton) {
            clearFields();
        } else if (source == exitButton) {
            exit();
        }
    }

    //exits program
    void exit() {
        System.exit(0);
    }

    /*
     * Add button: converts data to string values, price to double, validates
     * field entries are present, validates price is a numeric value, and
     * adds data to JTable
     */
    void addLine() {
        String strItemName = itemName.getText();
        String strOriginalPrice = originalPrice.getText();
        String strDepartment = (String) departmentBox.getSelectedItem();
        String strDiscount = discount.getText();
        String strRetailPrice;

        //validates amount as a double
        double doubleDiscount;
        double doublePrice;
        try {
            strDiscount = discount.getText();
            doubleDiscount = Double.parseDouble(strDiscount);

            strOriginalPrice = originalPrice.getText();
            doublePrice = Double.parseDouble(strOriginalPrice);

            double calRetailPrice = calculateRetail(doublePrice, doubleDiscount);
            strRetailPrice = Double.toString(calRetailPrice);
            retailPrice.setText(strRetailPrice);

        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "Price must be a numeric value.",
                    "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }


        //adds user input into JTable
        tableModel.setRowCount(itemCount + 1);//item count increment
        tableModel.setValueAt(strItemName, itemCount, 0);
        tableModel.setValueAt(strDepartment, itemCount, 1);
        tableModel.setValueAt(strOriginalPrice, itemCount, 2);
        tableModel.setValueAt(strDiscount, itemCount, 3);
        tableModel.setValueAt(strRetailPrice, itemCount, 4);
        itemCount++;

    }

    //clears fields for next entry
    void clearFields() {
        itemName.setText(null);
        originalPrice.setText(null);
        departmentBox.setSelectedIndex(0);
        discount.setText(null);
    }

    public static double calculateRetail(double wholesale,
            double markupPercent) {
        double discount = markupPercent / 100.0;
        return wholesale - (wholesale * discount);
    }

    public static void main(String[] args) {
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new RetailCalculator().setVisible(true);
            }
        });

    }
}