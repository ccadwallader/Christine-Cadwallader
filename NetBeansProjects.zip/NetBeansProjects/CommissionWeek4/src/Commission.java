/*
 * This program will calculate annual sales of a sales person.
 * Based on a 5% commission after acheiving 80% of the sales target 120,000
 * and also display the potential of total compensation in a table increase 5000 
 * until it reach 50% above annual sales.
 */

import java.util.ArrayList;
import java.util.Scanner;

public class Commission {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {


        ArrayList<Double> annualSales = new ArrayList<Double>();
        ArrayList name = new ArrayList();

        Scanner input = new Scanner(System.in); // enables keyboard input

        System.out.print("Please enter First Sales Person name: ");// prompts user for name of sales person
        name.add(input.nextLine());


        System.out.print("Please enter 2nd Sales Person name: ");// prompts user for name of sales person
        name.add(input.nextLine());

        System.out.print("Please enter annual sales First Person: ");//Prompts user for sales
        annualSales.add(input.nextDouble());


        System.out.print("Please enter annual sales Second Person: ");//Prompts user for sales
        annualSales.add(input.nextDouble());

        System.out.println();

        for (int i = 0; i < name.size(); i++) {
            String personName = (String) name.get(i);
            double personSale = annualSales.get(i);
            SalesPerson sp = new SalesPerson(); // enables salesPerson class

            System.out.println("Total Compensation of Sales Person " + personName + " is " + Math.round((sp.compensation(personSale))));

            System.out.println("SalePerson\tTotal Sales\tTotal Compensation");//Print column names

            double annualSalesCalc = personSale * 1.50;

            while (personSale <= annualSalesCalc) {
                System.out.println((personName) + "\t\t" + Math.round((personSale)) + "\t\t" + //print sales and compensation
                        Math.round((sp.compensation(personSale))));
                personSale = personSale + 5000;
            }

            System.out.println(); // print blank line

        }


        if (annualSales.get(0) > annualSales.get(1)) {

            System.out.println("Salesperson " + name.get(1) + "'s additional amount of sales that he must "
                    + "achieve to match or exceed the higher of the salesperson " + Math.round(annualSales.get(0)) + " is");
            System.out.println("$" + Math.round((annualSales.get(0) - annualSales.get(1))));

        } else if (annualSales.get(1) > annualSales.get(0)) {

            System.out.println("Salesperson " + name.get(0) + "'s additional amount of sales that he must "
                    + "achieve to match or exceed the higher of the salesperson " + Math.round(annualSales.get(1)) + " is");
            System.out.println("$" + Math.round((annualSales.get(1) - annualSales.get(0))));

        } else {
            System.out.println("Both have same compensation");
        }
    }
}
