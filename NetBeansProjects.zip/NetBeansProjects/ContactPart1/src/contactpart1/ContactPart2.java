/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package contactpart1;

import java.awt.Container;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.FileReader;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
/**
 *
 * @author ccadwallader
 */
public abstract class ContactPart2 extends JFrame implements ActionListener {

    public ContactPart2(String title) {
        super(title);
    }
    private JPanel outputPanel;
    private JPanel buttonPanel;
    private JTextArea outputTextArea;
    private JButton loadButton;
    private JScrollPane sbrText; // Scroll pane for text area
    private final int WINDOW_WIDTH = 600;
    private final int WINDOW_HEIGHT = 800;

    //sets JFrame constructor: calls build panel methods and adds panels, defines layout
    public ContactPart2() {
        super("Contact Info Part 2"); //calls JFrame constructor
        setSize(WINDOW_WIDTH, WINDOW_HEIGHT); //setting dimentions
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); //close on hitting 'X' button

        setVisible(true);
        //building panels
        buildOutputPanel();
        buildButtonPanel();

        Container contactContainer = getContentPane();
        //adding panels to GUI
        contactContainer.setLayout(new BoxLayout(contactContainer, BoxLayout.PAGE_AXIS));
        contactContainer.add(buttonPanel);
        contactContainer.add(outputPanel);
        pack();
    }

    //builds button panel: creates and adds buttons to panel and calls action listeners for buttons
    private void buildButtonPanel() {
        buttonPanel = new JPanel();

        loadButton = new JButton("Load Contacts");
        loadButton.addActionListener(this);

        buttonPanel.add(loadButton);
    }

    //builds output panel
    private void buildOutputPanel() {

        outputPanel = new JPanel();
        outputTextArea = new JTextArea(10, 40);
        outputTextArea.setLineWrap(true);
        sbrText = new JScrollPane(outputTextArea);
        sbrText.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);

        outputPanel.add(sbrText);

    }

    //Calls button methods when button is pressed   
    public void actionPerformed(ActionEvent event) {
        JButton source = (JButton) event.getSource();
        if (source == loadButton) {
            loadContacts();
        }

    }

    //Load Contacts
    void loadContacts() {
        try {
            FileReader f = new FileReader("Contact.txt");
            BufferedReader brk = new BufferedReader(f);
            String s;
            String s1 =""; 
            while ((s = brk.readLine()) != null) {
                s1 += s+"\n";
                outputTextArea.setText(s1);
            }
            System.out.println(s);
            
        } catch (Exception e) {
            System.out.println(e.toString());

        }

    }

    public static void main(String[] args) {
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new ContactPart1().setVisible(true);

            }
        });
    }
}

