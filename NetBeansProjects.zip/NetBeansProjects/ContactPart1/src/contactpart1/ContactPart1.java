/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package contactpart1;
import java.awt.Container;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.io.OutputStream;
import java.io.PrintStream;
import java.io.RandomAccessFile;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
/**
 *
 * @author ccadwallader
 */
public class ContactPart1 extends ContactPart2 {

    private JPanel contactPanel;
    private JPanel buttonPanel;
    private JTextField name;
    private JTextField age;
    private JTextField email;
    private JTextField phone;
    private JLabel nameLabel;
    private JLabel ageLabel;
    private JLabel emailLabel;
    private JLabel phoneLabel;
    private JButton submitButton;
    private JButton clearButton;
    private JButton exitButton;
    private final int WINDOW_WIDTH = 550;
    private final int WINDOW_HEIGHT = 150;
    static String outputString = "";
    int itemCount = 0;

    //sets JFrame constructor: calls build panel methods and adds panels, defines layout
    public ContactPart1() {
        super("Contact Info Part 1"); //calls JFrame constructor
        setSize(WINDOW_WIDTH, WINDOW_HEIGHT); //setting dimentions
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); //close on hitting 'X' button

        setVisible(true);
        //building panels
        buildContactPanel();
        buildButtonPanel();

        Container contactContainer = getContentPane();
        //adding panels to GUI
        contactContainer.setLayout(new BoxLayout(contactContainer, BoxLayout.PAGE_AXIS));
        contactContainer.add(contactPanel);
        contactContainer.add(buttonPanel);
    }

    //builds Contact panel
    private void buildContactPanel() {
        contactPanel = new JPanel();

        nameLabel = new JLabel("Name");
        name = new JTextField(19);

        ageLabel = new JLabel("Age");
        age = new JTextField(19);

        emailLabel = new JLabel("Email");
        email = new JTextField(19);

        phoneLabel = new JLabel("Phone");
        phone = new JTextField(19);

        contactPanel.add(nameLabel);
        contactPanel.add(name);
        contactPanel.add(ageLabel);
        contactPanel.add(age);
        contactPanel.add(emailLabel);
        contactPanel.add(email);
        contactPanel.add(phoneLabel);
        contactPanel.add(phone);

    }

    //builds button panel: creates and adds buttons to panel and calls action listeners for buttons
    private void buildButtonPanel() {
        buttonPanel = new JPanel();

        submitButton = new JButton("Save");
        submitButton.addActionListener(this);

        clearButton = new JButton("Clear");
        clearButton.addActionListener(this);

        exitButton = new JButton("Exit");
        exitButton.addActionListener(this);

        buttonPanel.add(submitButton);
        buttonPanel.add(clearButton);

        buttonPanel.add(exitButton);
    }

    //Calls button methods when button is pressed   
    public void actionPerformed(ActionEvent event) {
        JButton source = (JButton) event.getSource();
        if (source == submitButton) {
            saveContacts();
        } else if (source == clearButton) {
            clearFields();
        } else if (source == exitButton) {
            exit();
        }

    }

    /*
     * Validate age and save contact Details to Contact.txt file
     */
    void saveContacts() {

        String strName = name.getText();
        String strAge = age.getText();
        String strEmail = email.getText();
        String strPhone = phone.getText();

        //validates age as a double
        double doubleAge;
        try {
            doubleAge = Double.parseDouble(strAge);
            if (doubleAge > 120 || doubleAge < 0) {
                JOptionPane.showMessageDialog(null, "Age Must be between 0 an 120",
                        "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "Numeric Values for Age must be entered",
                    "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        //declare an array of 5 Contacts Name.
        String name[] = new String[5];

        try {
            name[itemCount] = strName;

            outputString = " Name: " + strName + "\n Age: " + strAge
                    + "\n Email: " + strEmail + "\n Phone: " + strPhone + "\n\n";

            if (itemCount == 0) {

                try {
                    RandomAccessFile fd = new RandomAccessFile("Contact.txt", "rw");
                    fd.setLength(0);
                } catch (Exception e) {
                    JOptionPane.showMessageDialog(null, e,
                            "Error", JOptionPane.ERROR_MESSAGE);
                    return;

                }
            }

            PrintStream out = new PrintStream(new AppendFileStream("Contact.txt"));

            out.print(outputString);

            itemCount++;

        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "You can only add 3-5 Contacts Information",
                    "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
    }

    //clears fields for next entry
    void clearFields() {
        name.setText(null);
        email.setText(null);
        age.setText(null);
        phone.setText(null);
    }

    //exits program
    void exit() {
        System.exit(0);
    }

    public static void main(String[] args) {
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new ContactPart1().setVisible(true);
            }
        });

    }
}

class AppendFileStream extends OutputStream {

    RandomAccessFile fd;

    public AppendFileStream(String file) throws IOException {

        fd = new RandomAccessFile(file, "rw");
        fd.seek(fd.length());

    }

    public void close() throws IOException {

        fd.close();

    }

    @Override
    public void write(int b) throws IOException {
        fd.write(b);
    }

    public void write(byte[] b) throws IOException {
        fd.write(b);
    }

    public void write(byte[] b, int off, int len) throws IOException {

        fd.write(b, off, len);

    }
}
