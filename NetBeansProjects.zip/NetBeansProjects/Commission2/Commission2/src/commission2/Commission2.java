/*
 * This program will calculate annual sales of a sales person.
 * Based on a 5% commission after acheiving 80% of the sales target 120,000
 * and also display the potential of total compensation in a table increase 5000 
 * until it reach 50% above annual sales.
 */
package commission2;

import java.util.Scanner;

/**
 *
 * @author ccadwallader
 */
public class Commission2 {
  /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {

//        String name;
        double annualSales;

        Scanner input = new Scanner(System.in); // enables keyboard input

        System.out.print("Please enter annual sales: ");//Prompts user for sales
        annualSales = input.nextDouble();

        SalesPerson salesPerson = new SalesPerson(); // enables salesPerson class

        System.out.println("Total Compensation: " //displays Total commission
                + Math.round((salesPerson.compensation(annualSales))));

        System.out.println(); // print blank line
        System.out.println("Total Sales\tTotal Compensation");//Print column names

        double annualSalesCalc = annualSales * 1.50;

        while (annualSales <= annualSalesCalc) {
            System.out.println(Math.round((annualSales)) + "\t\t" + //print sales and compensation
                    Math.round((salesPerson.compensation(annualSales))));
            annualSales = annualSales + 5000;
        }

    }
}
