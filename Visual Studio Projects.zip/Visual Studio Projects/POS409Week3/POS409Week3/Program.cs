﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;

namespace POS409Week3
{
    class Program
    {
        static void Main(string[] args)
        {
            while (true)
            {
                try
                {
                    Console.WriteLine("Enter a integer number:");
                    string input;
                    input = Console.ReadLine();
                    bool ac = true;
                    foreach (char c in input)
                        if (!char.IsDigit(c))
                        {
                            ac = false;
                            throw new MyException();
                            break;
                        }
                    if (ac)
                    {
                        Console.WriteLine("You have enter a integer number: " + input);
                        break;
                    }
                }
                catch (MyException e)
                {
                    Console.WriteLine(e);
                }
            }
            Console.ReadLine();
        }
    }

    class MyException : Exception
    {

        public override string Message
        {
            get
            {
                return "This is custom error: invalid integer number. Please try again";
            }
        }
    }

}
