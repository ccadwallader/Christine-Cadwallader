﻿Public Class Week3
    Dim totalCost As Decimal = 0

    Private Sub cbAppliances_SelectedValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cbAppliances.SelectedValueChanged
        Dim appliance As String

        ' Get value entered by the user
        appliance = cbAppliances.Text

        If appliance = "Washing Machine" Then
            CostGallonTextBox.Enabled = True
            NoGallonsTextBox.Enabled = True
        Else
            CostGallonTextBox.Clear()
            NoGallonsTextBox.Clear()
            CostGallonTextBox.Enabled = False
            NoGallonsTextBox.Enabled = False
        End If

    End Sub

    Private Sub tbCost_Validated(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles tbCost.Validated
        Dim cost As String

        ' Validate that cost entered is number display message box if value entered is incorrect
        Try
            cost = Convert.ToDouble(tbCost.Text)
        Catch ex As Exception
            If tbCost.Text <> "" Then
                MsgBox("Please enter numeric value in Cost/kW", , "Incorrect Value")
                tbCost.Focus()
            End If
        End Try

    End Sub

    Private Sub tbPower_Validated(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles tbPower.Validated
        Dim power As String

        ' Validate that power entered is number display message box if value entered is incorrect
        Try
            ' Validates that power is numeric
            power = Convert.ToDouble(tbPower.Text)
        Catch ex As Exception
            ' Display error message if value is incorrect
            If tbPower.Text <> "" Then
                MsgBox("Please enter numeric value in Power needed", , "Incorrect Value")
                ' Bring focus on power textbox
                tbPower.Focus()
            End If
        End Try

    End Sub

    Private Sub tbHour_Validated(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles tbHour.Validated
        Dim hours As String

        Try
            hours = Convert.ToDecimal(tbHour.Text)
            If (Convert.ToDouble(hours) > 24) Then
                MsgBox("Hours cannot be greater then 24", , "Incorrect Value")
                tbHour.Focus()
            End If
        Catch ex As Exception
            If tbHour.Text <> "" Then
                MsgBox("Please enter numeric value in Hours used", , "Incorrect Value")
                tbHour.Focus()
            End If
        End Try

    End Sub

    Private Sub CalculateButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CalculateButton.Click
        Dim cost, power, hours, noGallons, costGallons As String
        Dim appliance As String
        Dim appCost As Decimal

        cost = tbCost.Text
        power = tbPower.Text
        appliance = cbAppliances.Text

        ' Validate that appliance is selected
        If cbAppliances.Text = "" Then
            MsgBox("Please select an appliance", , "Value Required")
            cbAppliances.Focus()
            Exit Sub
        End If

        ' Validate that cost entered is number display message box if value entered is incorrect
        Try
            If tbCost.Text = "" Then
                MsgBox("Please enter Cost/kW", , "Value Required")
                tbCost.Focus()
                Exit Sub
            End If
            cost = Convert.ToDouble(tbCost.Text)
        Catch ex As Exception
            If tbCost.Text <> "" Then
                MsgBox("Please enter numeric value in Cost/kW", , "Incorrect Value")
                tbCost.Focus()
                Exit Sub
            End If
        End Try

        ' Validate that power entered is number display message box if value entered is incorrect
        Try
            ' Validates that power is numeric
            If tbPower.Text = "" Then
                MsgBox("Please enter Power needed", , "Value Required")
                ' Bring focus on power textbox
                tbPower.Focus()
                Exit Sub
            Else
                power = Convert.ToDouble(tbPower.Text)
            End If
        Catch ex As Exception
            ' Display error message if value is incorrect
            If tbPower.Text <> "" Then
                MsgBox("Please enter numeric value in Power needed", , "Incorrect Value")
                ' Bring focus on power textbox
                tbPower.Focus()
                Exit Sub
            End If
        End Try


        Try
            If tbHour.Text = "" Then
                MsgBox("Please enter Hours used", , "Value Required")
                tbHour.Focus()
                Exit Sub
            End If
            hours = Convert.ToDecimal(tbHour.Text)
            If (Convert.ToDouble(hours) > 24) Then
                MsgBox("Hours cannot be greater then 24", , "Incorrect Value")
                tbHour.Focus()
                Exit Sub
            End If
        Catch ex As Exception
            If tbHour.Text <> "" Then
                MsgBox("Please enter numeric value in Hours used", , "Incorrect Value")
                tbHour.Focus()
                Exit Sub
            End If
        End Try

        If appliance = "Washing Machine" Then
            Try
                ' Validates that Number of Gallons is numeric
                If NoGallonsTextBox.Text = "" Then
                    MsgBox("Please enter Number of Gallons", , "Value Required")
                    ' Bring focus on Number of Gallons textbox
                    NoGallonsTextBox.Focus()
                    Exit Sub
                Else
                    noGallons = Convert.ToDecimal(NoGallonsTextBox.Text)
                End If
            Catch ex As Exception
                If NoGallonsTextBox.Text <> "" Then
                    MsgBox("Please enter numeric value in Number of Gallons", , "Incorrect Value")
                    NoGallonsTextBox.Focus()
                    Exit Sub
                End If
            End Try

            Try
                ' Validates that Cost of Gallons is numeric
                If CostGallonTextBox.Text = "" Then
                    MsgBox("Please enter Cost of Gallons", , "Value Required")
                    ' Bring focus on Cost of Gallons textbox
                    CostGallonTextBox.Focus()
                    Exit Sub
                Else
                    costGallons = Convert.ToDecimal(CostGallonTextBox.Text)
                End If
            Catch ex As Exception
                If tbHour.Text <> "" Then
                    MsgBox("Please enter numeric value in Cost of Gallons", , "Incorrect Value")
                    tbHour.Focus()
                    Exit Sub
                End If
            End Try

            appCost = Convert.ToDouble(cost) * Convert.ToDouble(power) * Convert.ToDouble(hours) * costGallons * noGallons
            totalCost = appCost + totalCost
        Else
            appCost = Convert.ToDouble(cost) * Convert.ToDouble(power) * Convert.ToDouble(hours)
            totalCost = appCost + totalCost
        End If

        'lbMsg.Text = "Cost for operating these is " & totalCost.ToString("C")
        TotalTextBox.Text = totalCost.ToString("C")

        ' Add row using the Add subroutine.
        Dim n As Integer = DataGridView1.Rows.Add()
        DataGridView1.Rows.Item(n).Cells(0).Value = appliance
        DataGridView1.Rows.Item(n).Cells(1).Value = hours
        DataGridView1.Rows.Item(n).Cells(2).Value = appCost.ToString("C")

    End Sub

    Private Sub ClearButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ClearButton.Click
        cbAppliances.SelectedIndex = -1
        tbCost.Clear()
        tbHour.Clear()
        tbPower.Clear()
        'lbMsg.Text = ""
        NoGallonsTextBox.Clear()
        CostGallonTextBox.Clear()
    End Sub

    Private Sub NoGallonsTextBox_Validated(sender As Object, e As EventArgs) Handles NoGallonsTextBox.Validated
        Dim noGallons As String

        Try
            noGallons = Convert.ToDecimal(NoGallonsTextBox.Text)
        Catch ex As Exception
            If NoGallonsTextBox.Text <> "" Then
                MsgBox("Please enter numeric value in Number of Gallons", , "Incorrect Value")
                NoGallonsTextBox.Focus()
                Exit Sub
            End If
        End Try

    End Sub

    Private Sub CostGallonTextBox_Validated(sender As Object, e As EventArgs) Handles CostGallonTextBox.Validated
        Dim costGallons As String

        Try
            costGallons = Convert.ToDecimal(CostGallonTextBox.Text)
        Catch ex As Exception
            If CostGallonTextBox.Text <> "" Then
                MsgBox("Please enter numeric value in Cost f Gallons", , "Incorrect Value")
                CostGallonTextBox.Focus()
                Exit Sub
            End If
        End Try

    End Sub
End Class