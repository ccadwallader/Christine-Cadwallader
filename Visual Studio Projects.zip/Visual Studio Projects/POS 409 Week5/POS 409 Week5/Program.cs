﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace POS409Week5
{
    class Program
    {
        static void Main(string[] args)
        {
            Regex regex = new Regex(@"^((\(\d{3}\) ?)|(\d{3}-))?\d{3}-\d{4}$");
            Console.WriteLine("Valid phone number formats: 222-222-2222 or (444)444-4444");
            while (true)
            {
                try

                {
                    Console.WriteLine("Please enter your phone number: ");
                    string input = Console.ReadLine();
                    Match match = regex.Match(input);
                    if (match.Success)
                    {
                        Console.WriteLine("Phone number " + input + " is correct format");
                        break;
                    }
                    else
                        throw new MyException();
                }
                catch (MyException e)
                {
                    Console.WriteLine(e);
                }
            }
            Console.ReadKey();
        }
    }

    class MyException : Exception
    {
        public override string Message
        {
            get
            {
                return "*** Incorrect Format. Please try again. ***";
            }
        }
    }
}