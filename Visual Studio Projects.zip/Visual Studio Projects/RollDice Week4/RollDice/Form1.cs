﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;

namespace RollDice
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void rollButton_Click(object sender, EventArgs e)
        {
            int [] dice1, dice2;
            Random rnd = new Random();
            int j =0;

            dice1 = new int[100];
            dice2 = new int[100];

            dataGridView1.Rows.Clear();

            // Generate 2 sequences of 100 throws
            for (int i = 0; i < 100; i++)
            {
                dice1[i] = rnd.Next(1,7);
                dice2[i] = rnd.Next(1,7);

                    int n = dataGridView1.Rows.Add();
                    dataGridView1.Rows[i].Cells[0].Value = dice1[i];
                    dataGridView1.Rows[i].Cells[1].Value = dice2[i];

            }

            // LINQ to calculate the dice total of each throw
            var result = (from n1 in dice1.Select((item, index) => new { item, index })
                         join n2 in dice2.Select((item, index) => new { item, index }) on n1.index equals n2.index
                             select n1.item + n2.item).ToArray();

            // dispaly dice total
            for (int i = 0; i < 100; i++)
            {
                    dataGridView1.Rows[i].Cells[2].Value = result[i];
            }


            //Compare how these two sequences are different using IEnumerable.Except.
            IEnumerable<int> compareDice = dice1.Except(dice2);

            foreach (int diff in compareDice)
            {
                MessageBox.Show("Dice: " +diff, "Comparision", MessageBoxButtons.OKCancel, MessageBoxIcon.Asterisk);
            }
 
        }

    }
}
